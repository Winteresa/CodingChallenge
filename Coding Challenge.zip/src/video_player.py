"""A video player class."""

from .video_library import VideoLibrary
from .video_playlist import Playlist
import random

class VideoPlayer:
    """A class used to represent a Video Player."""

    def __init__(self):
        self._video_library = VideoLibrary()
        self.currentvideo = None
        self.ispaused = False
        self.playlists = {}

    def number_of_videos(self):
        num_videos = len(self._video_library.get_all_videos())
        print(f"{num_videos} videos in the library")

    def show_all_videos(self):
        """Returns all videos."""
        print ("Here's a list of all available videos:")
        videos = self._video_library.get_all_videos()
        videos.sort(key=lambda x: x.title)
        for row in videos:
            print(row.title + " (" + row.video_id + ") [" + " ".join(row.tags) + "]")

    def play_video(self, video_id):
        """Plays the respective video. """
        video = self._video_library.get_video(video_id)
        if not video :
            print("Cannot play video: Video does not exist.")
        else:
            if self.currentvideo :
                print("Stopping video: " + self.currentvideo.title)
            print("Playing video: " + video.title)
            self.currentvideo = video
            self.ispaused = False

    def stop_video(self):
        """Stops the current video."""
        if self.currentvideo :
            print ("Stopping video: " + self.currentvideo.title)
        else :
            print("Cannot stop video: No video is currently playing.")
        self.currentvideo = None

    def play_random_video(self):
        """Plays a random video from the video library."""
        all_videos = self._video_library.get_all_videos()

        video = random.choice(all_videos)

        if self.currentvideo:
            print("Stopping video: " + self.currentvideo.title)
        print("Playing video: " + video.title)
        self.currentvideo = video
        self.ispaused = False

    def pause_video(self):
        """Pauses the current video."""
        if self.currentvideo and self.ispaused :
            print("Video already paused: " + self.currentvideo.title)
        elif self.currentvideo and not self.ispaused :
            print("Pausing video: " + self.currentvideo.title)
            self.ispaused = True
        else:
            print("Cannot pause video: No video is currently playing.")

    def continue_video(self):
        """Resumes playing the current video."""
        if self.currentvideo and self.ispaused :
            print("Continuing video: " + self.currentvideo.title)
            self.ispaused = False
        elif self.currentvideo and not self.ispaused :
            print("Cannot continue video: Video is not paused.")
        else :
            print("Cannot continue video: No video is currently playing.")


    def show_playing(self):
        """Displays video currently playing."""
        if self.currentvideo and self.ispaused :
            print("Currently playing: " + self.currentvideo.title + " (" + self.currentvideo.video_id
                  + ") [" + " ".join(self.currentvideo.tags) + "]" + " - PAUSED")
        elif self.currentvideo and not self.ispaused :
            print("Currently playing: " + self.currentvideo.title + " (" + self.currentvideo.video_id
                  + ") [" + " ".join(self.currentvideo.tags) + "]")
        else :
            print("No video is currently playing.")


    def create_playlist(self, playlist_name):
        if self.playlists.get(playlist_name, None):
            print('Cannot create playlist: A playlist with the same name already exists.')
        else:
            self.playlists[playlist_name] = Playlist(playlist_name)
            print("Successfully created new playlist: " + playlist_name)

    def add_to_playlist(self, playlist_name, video_id):
        if not self.playlists.get(playlist_name, None):
            print("Cannot add video to " + playlist_name + " : Playlist does not exist. ")
        elif not (video:= self._video_library.get_video(video_id)) :
            print("Cannot add video to " + playlist_name + " : Video does not exist. ")
        else :
            self.playlists[playlist_name].add_video(video)

    def show_all_playlists(self):
        all_playlist = self.playlists.values()
        if len(all_playlist) == 0:
            print("No playlists exist yet.")
        else:
            print("Showing all playlists: ")
            for item in all_playlist:
                print(item.name)

    def show_playlist(self, playlist_name):
        """Display all videos in a playlist with a given name.

        Args:
            playlist_name: The playlist name.
        """
        print("show_playlist needs implementation")

    def remove_from_playlist(self, playlist_name, video_id):
        """Removes a video to a playlist with a given name.

        Args:
            playlist_name: The playlist name.
            video_id: The video_id to be removed.
        """
        print("remove_from_playlist needs implementation")

    def clear_playlist(self, playlist_name):
        """Removes all videos from a playlist with a given name.

        Args:
            playlist_name: The playlist name.
        """
        print("clears_playlist needs implementation")

    def delete_playlist(self, playlist_name):
        """Deletes a playlist with a given name.

        Args:
            playlist_name: The playlist name.
        """
        print("deletes_playlist needs implementation")

    def search_videos(self, search_term):
        """Display all the videos whose titles contain the search_term.

        Args:
            search_term: The query to be used in search.
        """
        print("search_videos needs implementation")

    def search_videos_tag(self, video_tag):
        """Display all videos whose tags contains the provided tag.

        Args:
            video_tag: The video tag to be used in search.
        """
        print("search_videos_tag needs implementation")

    def flag_video(self, video_id, flag_reason=""):
        """Mark a video as flagged.

        Args:
            video_id: The video_id to be flagged.
            flag_reason: Reason for flagging the video.
        """
        print("flag_video needs implementation")

    def allow_video(self, video_id):
        """Removes a flag from a video.

        Args:
            video_id: The video_id to be allowed again.
        """
        print("allow_video needs implementation")
