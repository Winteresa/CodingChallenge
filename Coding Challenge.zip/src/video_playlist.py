"""A video playlist class."""


class Playlist:
    """A class used to represent a Playlist."""

    def __init__(self, name):
        self.name = name
        self.videos = {}

    def add_video(self, video):
        if self.videos.get(video.video_id, None):
            print("Cannot add video to " + self.name + " : Video already added.")
        else :
            self.videos[video.video_id] = video
            print("Added video to " + self.name + " : " + video.title)

